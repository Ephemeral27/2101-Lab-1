package ca.mohaghegh.navid;

/**
 * Dog object.
 */
public class Dog extends Animal implements Lovable {

    /**
     * Simplified age conversion used by this programming example; not a biological model.
     */
    public static final int HUMAN_AGE_CONVERSION_FACTOR = 7;


    public Dog(String name) {
        super(name);
    }

    /**
     * Will return the corresponding human age for this dog
     * @return the human age for this dog.
     */
    public int getHumanAge() {
        return super.getAge() * HUMAN_AGE_CONVERSION_FACTOR;
    }


    private int howLovelyIsThisDog = 10;

    public int getHowLovely() {
        return this.howLovelyIsThisDog;
    }

    public void setHowLovely(int howLovelyIsThisDog) {
        this.howLovelyIsThisDog = howLovelyIsThisDog;
    }

    @Override
    public String toString() {
        return "Dog{" +
                "name='" + super.getName() + '\'' +
                ", age=" + super.getAge() +
                ", amountOfFoodPerDay=" + super.getamountOfFoodPerDay() +
                ", howLovelyIsThisDog=" + this.getHowLovely() +
                '}';
    }
}
